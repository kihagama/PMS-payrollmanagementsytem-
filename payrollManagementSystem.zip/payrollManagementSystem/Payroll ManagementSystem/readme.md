# Payroll-Management-System

A simple Payroll Management System where you can

Add
Update
Delete
Search

Employees from the System

Add
Update
Delete

Salary details

Add
Update
Delete

Leave details

Generate and Print Pay Slips

Database file is also included

GUI is done using Java Swing Framework

USAGE PROCEDURES:
install xamp server
start the apache and mysql servers
create a Payroll Database using phpmyadmin
import the payroll Database from the Database folder
LOGIN DETAILS
admin:
username:ismael
password :1234
Employees:
username:abu
password:12345
